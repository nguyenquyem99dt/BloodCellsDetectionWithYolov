
BCCD - v1 resize-416x416
==============================

This dataset was exported via roboflow.ai on March 23, 2020 at 7:11 AM GMT

It includes 364 images.
Cells are annotated in YOLO v3 (Keras) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


